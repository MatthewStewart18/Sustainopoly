
public class Investment {

	public int getPrice() {
		// TODO Auto-generated method stub
		return 0;
	}

}
