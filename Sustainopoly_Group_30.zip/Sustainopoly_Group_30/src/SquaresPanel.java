import javax.swing.JScrollPane;

public class SquaresPanel extends JScrollPane {

}
