package test;
import org.junit.Test;
import sustainopoly.Game;
import junit.framework.TestCase;

public class PlayerTest extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	@Test
	public void testPlayer() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetName() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetPosition() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetMoney() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetTime() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddMoney() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddTime() {
		fail("Not yet implemented");
	}

	@Test
	public void testPay() {
		fail("Not yet implemented");
	}

	@Test
	public void testMove() {
		fail("Not yet implemented");
	}

	@Test
	public void testMoveTo() {
		fail("Not yet implemented");
	}

	@Test
	public void testInvestIn() {
		fail("Not yet implemented");
	}

	@Test
	public void testListInvestments() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetPlayerID() {
		fail("Not yet implemented");
	}

}
